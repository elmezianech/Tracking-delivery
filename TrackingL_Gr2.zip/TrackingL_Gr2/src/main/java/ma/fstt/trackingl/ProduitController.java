package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.ProduitDAO;
import ma.fstt.model.Produit;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Long.parseLong;

public class ProduitController implements Initializable {

    @FXML
    private Button dashboard;

    @FXML
    private TextField nom ;


    @FXML
    private TextField quantite ;


    @FXML
    private TableView<Produit> mytable2 ;


    @FXML
    private TableColumn<Produit ,Long> col_id ;

    @FXML
    private TableColumn <Produit ,String> col_nom ;

    @FXML
    private TableColumn <Produit ,Long> col_quantite ;


    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            ProduitDAO produitDAO = new ProduitDAO();

            Produit liv = new Produit(0l , nom.getText() , parseLong(quantite.getText()));

            produitDAO.save(liv);


            UpdateTable();




        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }


    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Produit,Long>("id_produit"));
        col_nom.setCellValueFactory(new PropertyValueFactory<Produit,String>("nom"));

        col_quantite.setCellValueFactory(new PropertyValueFactory<Produit,Long>("quantite"));



        mytable2.setItems(this.getDataProduits());
    }

    public static ObservableList<Produit> getDataProduits(){

        ProduitDAO produitDAO = null;

        ObservableList<Produit> listfx = FXCollections.observableArrayList();

        try {
            produitDAO = new ProduitDAO();
            for (Produit ettemp : produitDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }
    @FXML
    protected void onUpdateButtonClick() {

        Produit selectedProduit = mytable2.getSelectionModel().getSelectedItem();

        if (selectedProduit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for update");
            return;
        }

        try {
            ProduitDAO produitDAO = new ProduitDAO();

            // Update the Produit object with the new data
            selectedProduit.setNom(nom.getText());
            selectedProduit.setQuantite(parseLong(quantite.getText()));

            produitDAO.update(selectedProduit);

            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    protected void onDeleteButtonClick() {

        Produit selectedProduit = mytable2.getSelectionModel().getSelectedItem();

        if (selectedProduit == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for deletion");
            return;
        }

        try {
            ProduitDAO produitDAO = new ProduitDAO();
            produitDAO.delete(selectedProduit);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void afficherMenu(ActionEvent event) {
        try {
            // Load the FXML file for the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu-view.fxml"));
            Parent root = loader.load();

            // Create a new scene with the root node
            Scene scene = new Scene(root);

            // Get the current stage and set the new scene
            Stage stage = (Stage) dashboard.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}