package ma.fstt.trackingl;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.fstt.model.Commande;
import ma.fstt.model.CommandeDAO;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static java.lang.Long.parseLong;
import static java.lang.Double.parseDouble;


public class CommandeController implements Initializable {

    @FXML
    private Button dashboard;

    @FXML
    private Button prixTotal;

    @FXML
    private TextField afficherPrix ;

    @FXML
    private TextField date ;


    @FXML
    private TextField id_produit ;

    @FXML
    private TextField id_livreur ;

    @FXML
    private TextField prix ;

    @FXML
    private TableView<Commande> mytable3 ;


    @FXML
    private TableColumn<Commande ,Long> col_id ;

    @FXML
    private TableColumn <Commande,String> col_date ;

    @FXML
    private TableColumn <Commande ,Long> col_produit ;

    @FXML
    private TableColumn <Commande ,Long> col_livreur ;

    @FXML
    private TableColumn <Commande ,Double> col_prix ;

    @FXML
    protected void onSaveButtonClick() {

        // accees a la bdd

        try {
            CommandeDAO commandeDAO = new CommandeDAO();

            Commande com = new Commande(0l , date.getText() , parseLong(id_produit.getText()) , parseLong(id_livreur.getText()), parseDouble(prix.getText()));

            commandeDAO.save(com);


            UpdateTable();




        } catch (SQLException e) {
            throw new RuntimeException(e);
        }


    }


    public void UpdateTable(){
        col_id.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id_commande"));
        col_date.setCellValueFactory(new PropertyValueFactory<Commande,String>("date"));

        col_produit.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id_produit"));
        col_livreur.setCellValueFactory(new PropertyValueFactory<Commande,Long>("id_livreur"));
        col_prix.setCellValueFactory(new PropertyValueFactory<Commande,Double>("prix"));


        mytable3.setItems(this.getDataCommandes());
    }

    public static ObservableList<Commande> getDataCommandes(){

        CommandeDAO commandeDAO = null;

        ObservableList<Commande> listfx = FXCollections.observableArrayList();

        try {
            commandeDAO = new CommandeDAO();
            for (Commande ettemp : commandeDAO.getAll())
                listfx.add(ettemp);

        }catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return listfx ;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        UpdateTable();
    }

    @FXML
    protected void onUpdateButtonClick() {

        Commande selectedCommande = mytable3.getSelectionModel().getSelectedItem();

        if (selectedCommande == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for update");
            return;
        }

        try {
            CommandeDAO commandeDAO = new CommandeDAO();

            // Update the Commande object with the new data
            selectedCommande.setDate(date.getText());
            selectedCommande.setId_produit(parseLong(id_produit.getText()));
            selectedCommande.setId_livreur(parseLong(id_livreur.getText()));
            selectedCommande.setPrix(parseDouble(prix.getText()));

            commandeDAO.update(selectedCommande);

            UpdateTable();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @FXML
    protected void onDeleteButtonClick() {

        Commande selectedCommande = mytable3.getSelectionModel().getSelectedItem();

        if (selectedCommande == null) {
            // No item selected, display error message
            System.out.println("Error: no item selected for deletion");
            return;
        }

        try {
            CommandeDAO commandeDAO = new CommandeDAO();
            commandeDAO.delete(selectedCommande);
            UpdateTable();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    @FXML
    void afficherMenu(ActionEvent event) {
        try {
            // Load the FXML file for the new scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("menu-view.fxml"));
            Parent root = loader.load();

            // Create a new scene with the root node
            Scene scene = new Scene(root);

            // Get the current stage and set the new scene
            Stage stage = (Stage) dashboard.getScene().getWindow();
            stage.setScene(scene);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    protected void onPrixTotalClick(ActionEvent event) {
        Commande selectedCommande = mytable3.getSelectionModel().getSelectedItem();
        if (selectedCommande != null) {
            Long Id_livreur = selectedCommande.getId_livreur();
            double total = 0;
            for (Commande commande : getDataCommandes()) {
                if (commande.getId_livreur() == Id_livreur) {
                    total += commande.getPrix();
                }
            }
            afficherPrix.setText("Le prix total des commandes livrées par ce livreur est \n"+String.format("%.2f", total)+"$");
        }
    }
}

