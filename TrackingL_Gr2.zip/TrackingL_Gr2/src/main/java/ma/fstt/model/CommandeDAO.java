package ma.fstt.model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommandeDAO extends BaseDAO<Commande>{
    public CommandeDAO() throws SQLException {

        super();
    }

    @Override
    public void save(Commande object) throws SQLException {

        String request = "insert into commande (Date, Id_produit, Id_livreur, Prix) values (? , ? , ?, ?)";

        // mapping objet table

        this.preparedStatement = this.connection.prepareStatement(request);
        // mapping
        this.preparedStatement.setString(1 , object.getDate());

        this.preparedStatement.setLong(2 , object.getId_produit());

        this.preparedStatement.setLong(3 , object.getId_livreur());

        this.preparedStatement.setDouble(4 , object.getPrix());

        this.preparedStatement.execute();
    }

    @Override
    public void update(Commande object) throws SQLException {

        String request = "update commande set Date = ?, Id_produit = ?, Id_livreur = ?, Prix = ? where id_commande = ?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(request);

        // mapping
        this.preparedStatement.setString(1 , object.getDate());
        this.preparedStatement.setLong(2 , object.getId_produit());
        this.preparedStatement.setLong(3 , object.getId_livreur());
        this.preparedStatement.setDouble(4 , object.getPrix());
        this.preparedStatement.setLong(5 , object.getId_commande());

        this.preparedStatement.executeUpdate();
    }

    @Override
    public void delete(Commande object) throws SQLException {

        String request = "delete from commande where id_commande = ?";

        // mapping objet table
        this.preparedStatement = this.connection.prepareStatement(request);

        // mapping
        this.preparedStatement.setLong(1 , object.getId_commande());

        this.preparedStatement.executeUpdate();
    }

    @Override
    public List<Commande> getAll()  throws SQLException {

        List<Commande> mylist = new ArrayList<Commande>();

        String request = "select * from commande ";

        this.statement = this.connection.createStatement();

        this.resultSet =   this.statement.executeQuery(request);

// parcours de la table
        while ( this.resultSet.next()){

// mapping table objet
            mylist.add(new Commande(this.resultSet.getLong(1) ,
                    this.resultSet.getString(2) , this.resultSet.getLong(3), this.resultSet.getLong(4), this.resultSet.getDouble(5)));


        }


        return mylist;
    }

    @Override
    public Commande getOne(Long id) throws SQLException {
        return null;
    }


}

