package ma.fstt.model;

public class Produit {
    private Long Id_produit ;

    private String Nom ;

    private Long Quantite ;

    public Produit() {
    }

    public Produit(Long Id_produit, String Nom, Long Quantite) {
        this.Id_produit = Id_produit;
        this.Nom = Nom;
        this.Quantite = Quantite;
    }

    public Long getId_produit() {
        return Id_produit;
    }

    public void setId_produit(Long id_produit) {
        this.Id_produit = Id_produit;
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public Long getQuantite() {
        return Quantite;
    }

    public void setQuantite(Long Quantite) {
        this.Quantite = Quantite;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "Id_produit=" + Id_produit +
                ", Nom='" + Nom + '\'' +
                ", Quantite='" + Quantite + '\'' +
                '}';
    }
}
