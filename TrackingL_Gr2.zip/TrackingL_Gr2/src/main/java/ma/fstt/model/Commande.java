package ma.fstt.model;


// java bean
public class Commande {
    private Long Id_commande ;

    private String Date ;

    private Long Id_produit ;

    private Long Id_livreur ;

    private Double Prix ;

    public Commande(Long Id_commande, String Date, Long Id_produit, Long Id_livreur, Double Prix) {
        this.Id_commande = Id_commande;
        this.Date = Date;
        this.Prix = Prix;
        this.Id_produit = Id_produit;
        this.Id_livreur = Id_livreur;
    }

    public Long getId_commande() {
        return Id_commande;
    }

    public void setId_commande(Long Id_commande) {
        this.Id_commande = Id_commande;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public Long getId_produit() {
        return Id_produit;
    }

    public void setId_produit(Long Id_produit) {
        this.Id_produit = Id_produit;
    }

    public Long getId_livreur() {
        return Id_livreur;
    }

    public void setId_livreur(Long Id_livreur) {
        this.Id_livreur = Id_livreur;
    }

    public Double getPrix() {
        return Prix;
    }

    public void setPrix(Double Prix) {
        this.Prix = Prix;
    }

    @Override
    public String toString() {
        return "Commande{" +
                "Id_commande=" + Id_commande +
                ", Date='" + Date + '\'' +
                ", Id_produit='" + Id_produit + '\'' +
                ", Id_livreur='" + Id_livreur + '\'' +
                ", Prix='" + Prix + '\'' +
                '}';
    }
}
